//
//  WellcomeVC.swift
//  TestProject
//
//  Created by Avadh Mewada on 15/03/21.
//

import UIKit

class WellcomeVC: UIViewController {

    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubTitle: UILabel!
    @IBOutlet weak var introImageHeight: NSLayoutConstraint! //250
    @IBOutlet weak var introImageView: UIImageView!
    @IBOutlet weak var lblBottom: UILabel!
    @IBOutlet weak var btnBottom: UIButton!
    
    @IBOutlet weak var googleBtn: UIButton!
    @IBOutlet weak var facebookBtn: UIButton!
    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var stackTxtFields: UIStackView!
    @IBOutlet weak var stackViewHeight: NSLayoutConstraint!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var viewConditions: UIView!
    @IBOutlet weak var viewConditionsHeight: NSLayoutConstraint! // 40
    @IBOutlet weak var radioBtnImg: UIImageView!
    
    @IBOutlet weak var lblConditions: UILabel!
    @IBOutlet weak var btnForgotPass: UIButton!
    @IBOutlet weak var btnConditions: UIButton!
    
    
    
    let intrImgDefaultHeight: CGFloat = 250
    let stackViewDefaultHeight: CGFloat = 145
    
    var isUsingTxtFields = false
    var isNewUser = false
    var isAgreed = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.SetupWellcome()
        
        
    }
    
  
    
    @IBAction func onClickGoogleLogin(_ sender: Any) {}
    @IBAction func onClickFBlogin(_ sender: Any) {}
    @IBAction func onClickLoginWithEmail(_ sender: Any) {
        self.isUsingTxtFields = true
        self.loginWithEmail()
    }
    @IBAction func onClickSignUp(_ sender: Any) {
        self.isUsingTxtFields = true
        signUpWithEmail()
    }
    @IBAction func onClickLogin(_ sender: Any) {
    }
    @IBAction func onClickConditions(_ sender: Any) {
        if radioBtnImg.image == UIImage(named: "unSelected") {
            isAgreed = true
            radioBtnImg.image = UIImage(named: "selected")
        }else{
            isAgreed = false
            radioBtnImg.image = UIImage(named: "unSelected")
        }
    }
    @IBAction func onClickForgotPass(_ sender: Any) {
    }
    

}
extension WellcomeVC {
    
    func SetupWellcome(){
        signUpBtn.AppButton(Title: "Sign Up")
        radioBtnImg.image = UIImage(named: "unSelected")
        googleBtn.layer.cornerRadius = 6
        googleBtn.layer.borderWidth = 0.5
        googleBtn.layer.borderColor = UIColor.lightGray.cgColor
        googleBtn.layer.masksToBounds = true
        
        facebookBtn.layer.cornerRadius = 6
        facebookBtn.layer.masksToBounds = true
        
        txtEmail.AppTextFields(hintText: "Email")
        txtEmail.setLeftPaddingPoints(20)
        txtPassword.AppTextFields(hintText: "Password")
        txtPassword.setLeftPaddingPoints(20)
        
        stackTxtFields.isHidden = true
        stackViewHeight.constant = 0
        
        viewConditionsHeight.constant = 0
        viewConditions.isHidden = true
        
        btnForgotPass.isHidden = true
        
        
    }
    
    func loginWithEmail(){
        
        
        lblTitle.text = "Login Now"
        lblSubTitle.text = "Please Login to continue using Helloji"
        introImageView.isHidden = true
        introImageHeight.constant = 0
        signUpBtn.AppButton(Title: "Login")
        stackTxtFields.isHidden = false
        stackViewHeight.constant = stackViewDefaultHeight
        
        btnBottom.setTitle("Don't have an account?", for: .normal)
        lblBottom.text = "Sign Up"
        lblBottom.textColor = AppColors.appBlueColor
        
        viewConditions.isHidden = false
        viewConditionsHeight.constant = 40
        
        lblConditions.text = "Remember Me"
        btnForgotPass.isHidden = false
    }
    
    func signUpWithEmail(){
        lblTitle.text = "Sign Up"
        lblSubTitle.text = "Please sign up to continue using Helloji"
        introImageView.isHidden = true
        introImageHeight.constant = 0
        signUpBtn.AppButton(Title: "Sign Up")
        stackTxtFields.isHidden = false
        stackViewHeight.constant = stackViewDefaultHeight
        btnBottom.setTitle("Already have an account?", for: .normal)
        lblBottom.text = "Login"
        lblBottom.textColor = AppColors.appBlueColor
        lblConditions.text = "I agree with privacy policy"
        btnForgotPass.isHidden = true
        viewConditions.isHidden = false
        viewConditionsHeight.constant = 40

    }
}
