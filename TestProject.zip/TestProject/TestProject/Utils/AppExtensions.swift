//
//  AppExtensions.swift
//  TestProject
//
//  Created by Avadh Mewada on 15/03/21.
//

import Foundation
import UIKit

struct AppColors{
    
    public static let appBlueColor = UIColor(red: 0/255, green: 111/255, blue: 255/255, alpha: 1.0)
}

extension UIButton {
    
    func AppButton(Title: String){
        self.layer.cornerRadius = 6
        self.layer.masksToBounds = true
        self.setTitle(Title, for: .normal)
        self.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        self.tintColor = .white
        self.layer.backgroundColor = AppColors.appBlueColor.cgColor
            
    }
}
extension UITextField {
    
    func AppTextFields(hintText: String){
        self.layer.cornerRadius = 6
        self.layer.masksToBounds = true
        self.layer.borderColor = UIColor.lightGray.cgColor
        self.layer.borderWidth = 0.5
        self.placeholder = hintText
    }
    
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}
